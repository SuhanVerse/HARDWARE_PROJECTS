# RHYX-M21-CAM
This is a repo for the usage of the above ESP32 camera. The code for this camera is not there in the example given Arduino IDE.

![20250308_180658](https://github.com/user-attachments/assets/ef2ba369-c112-42d7-bcf7-abca5b22efb2)

# Usage
1. Set the board to ```AI Thinker ESP32-CAM```
2. Set the correct port
3. Change your settings to the following in Tools:

![Screenshot 2025-03-08 180305](https://github.com/user-attachments/assets/891c4e5f-b974-41ae-b499-fedd4e655182)

4. Upload the code
